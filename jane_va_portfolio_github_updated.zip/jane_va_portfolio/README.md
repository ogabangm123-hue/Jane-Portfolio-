# Mary Jane Ogabang — Remote Support & Creative Portfolio

A responsive, single-page portfolio website for entry-level virtual assistant, customer support, content support, and social media assistant applications.

## Before publishing
1. Open `index.html` and replace `Add your professional email here` with your professional email.
2. Replace the GitHub placeholder with your GitHub profile URL.
3. Check the dates and job descriptions for accuracy.
4. Replace or supplement the concept samples with your own Canva and CapCut work when available.
5. Do not describe concept samples as paid client work.

## Publish with GitHub Pages
1. Create or open your GitHub repository.
2. Upload `index.html` and `README.md` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)` folder, then click **Save**.
6. Wait for GitHub Pages to publish the site. Your site URL will appear in the Pages settings.

## Customize
The website uses plain HTML and CSS. You can edit the text and colors directly inside `index.html`. No build tools are required.
